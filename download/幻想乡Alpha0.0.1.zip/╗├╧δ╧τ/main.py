#幻想乡：一个大型游戏项目
#导入库
import pygame
import sys
#编写背景库
class backgroundPic:
    def __init__(self):
        self.img = ["Menu.png"] #初始化背景图片列表
    def process(self,mode):    #管理背景图片
        global eventlist
        eventlist.append((self.img[mode],0,0))   #添加事件
#编写ui库
class ui:
    def __init__(self,result,mode):
        self.imglist = [("Choose1.png","Choose2.png","Choose3.png")]      #初始化ui造型列表
        self.largemode = [3]
        self.mode = mode
        self.result = result
    def change_mode(self,keyList,keyup):     #切换ui按键
        if keyList[pygame.K_UP]:
            self.mode -= 1
        elif keyList[pygame.K_DOWN]:
            self.mode += 1
        self.mode = self.mode % 3
        return self.mode
    def show(self):           #打印ui
        global eventList
        eventlist.append((self.imglist[self.result][self.mode],0,0))
        
def loop():     #游戏主循环
    global uimode
    bp.process(mode) #管理背景图片
    #新建ui类
    Ui = ui(mode,uimode)
    uimode = Ui.change_mode(keyList,keyUp)
    Ui.show()
#uimode管理器
uimode = 0
#初始化pygame
pygame.init()
pygame.mixer.init()
#新建一个窗口对象
screen = pygame.display.set_mode([800,600])
#设置窗口标题
pygame.display.set_caption('幻想乡')
#导入图片
Menu = pygame.image.load('Menu.png')
#导入音乐
pygame.mixer.music.load('Menu.mp3')
#循环播放音乐
pygame.mixer.music.play(-1)
#初始化事件列表
eventlist = []
#游戏状态
mode = 0
#新建一个背景管理类
bp = backgroundPic()
keyUp = True
#游戏主循环部分
while True:   #游戏循环
    for event in pygame.event.get():
        if event.type == pygame.QUIT:     #窗口关闭事件
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYUP:
            keyUp = True
        else:
            keyUp = False
    #获取键盘事件
    keyList = pygame.key.get_pressed()
    loop()
    for i in eventlist:   #绘制图片
        img = pygame.image.load(i[0])
        screen.blit(img,(i[1],i[2]))
    eventlist = []       #清空事件列表
    pygame.display.update()    #刷新屏幕
